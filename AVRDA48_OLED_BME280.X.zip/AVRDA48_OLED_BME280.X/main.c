 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.0
*/

/*
? [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "bme280.h"
#include "OLED128x64.h"

// #define BME280_ADDR     0x76

#define DEFAULT_STANDBY_TIME    BME280_STANDBY_HALFMS
#define DEFAULT_FILTER_COEFF       BME280_FILTER_COEFF_OFF
#define DEFAULT_TEMP_OSRS           BME280_OVERSAMP_X1
#define DEFAULT_PRESS_OSRS          BME280_OVERSAMP_X1
#define DEFAULT_HUM_OSRS            BME280_OVERSAMP_X1
#define DEFAULT_SENSOR_MODE     BME280_FORCED_MODE

volatile unsigned char  I2C_Wbuffer[16];   
volatile unsigned char  I2C_Rbuffer[16] ;
unsigned char             ASCII_Buffer[20];

volatile bool bRTCOverflow = 0 ;
uint8_t     StateMachine = 0 ;
uint16_t    Counter = 0 ;
uint16_t    adcResult ;

float   BME280_Temp ;
float   BME280_Pressure ;
float   BME280_Humidity ;


void    LED_Shift(void) ;
void WeatherStation_initialize(void) ;
void WeatherClick_readSensors(void) ;

void    RTC_OVF_Callback(void)
{
    bRTCOverflow = 1 ;
}

/*
    Main application
*/

int main(void)
{
    SYSTEM_Initialize();
    // Important workaround for I2C Pin MAX setting
    // Set  PC2/PC3 as Host/Client pin of TWI0 
    // PORTMUX.TWIROUTEA = 0b00000000;             
    // Important workaround for I2C Pin MAX setting 
    RTC_SetOVFIsrCallback(RTC_OVF_Callback);

        OLED_Init();                                                    
        OLED_CLS();
        OLED_Put8x16Str(0,0,"MCU:AVR128DA48");
        
        WeatherStation_initialize();       
        
    while(1)
    {
        if (bRTCOverflow ==1)
        {
            LED_Shift();
            bRTCOverflow = 0;
                
           WeatherClick_readSensors();
            BME280_Temp = BME280_getTemperature();
            BME280_Pressure = BME280_getPressure();
            BME280_Humidity = BME280_getHumidity();
               sprintf (ASCII_Buffer,"Temp= %5.2f C", BME280_Temp) ;
                OLED_Put8x16Str(0,2,(uint8_t*)ASCII_Buffer) ;      
                    sprintf (ASCII_Buffer,"Hum.=%5.2f %c", BME280_Humidity,'%') ;
                    OLED_Put8x16Str(0,4,(uint8_t*)ASCII_Buffer) ;      
                        sprintf (ASCII_Buffer,"Pre.=%5.2f Kpa", BME280_Pressure) ;
                        OLED_Put8x16Str(0,6,(uint8_t*)ASCII_Buffer) ;                         
                    
        }
    }    
}

void    LED_Shift(void)
{
 switch(StateMachine)
        {
            case 0:
                LED1_SetHigh();
                LED2_SetLow();
                LED3_SetLow();
                LED4_SetLow();
                StateMachine ++ ;
                break ;
            case 1:
                LED1_SetLow();
                LED2_SetHigh();
                LED3_SetLow();
                LED4_SetLow();    
                StateMachine ++ ;
                break ;
            case 2 :
                LED1_SetLow();
                LED2_SetLow();
                LED3_SetHigh();
                LED4_SetLow();      
                StateMachine ++ ;
                break ;
            case 3:
                LED1_SetLow();
                LED2_SetLow();
                LED3_SetLow();
                LED4_SetHigh();    
                StateMachine ++ ;
                break ;
            case 4:
                LED1_SetLow();
                LED2_SetLow();
                LED3_SetHigh();
                LED4_SetLow();       
                StateMachine ++ ;
                break ;                
            case 5:
                LED1_SetLow();
                LED2_SetHigh();
                LED3_SetLow();
                LED4_SetLow();      
                StateMachine = 0 ;
                break ;                                               
            default :
                break ;
                                           
        }    
}


void WeatherClick_readSensors(void) {
    if (DEFAULT_SENSOR_MODE == BME280_FORCED_MODE) {
        BME280_startForcedSensing();
    }
    BME280_readMeasurements();
}

void WeatherStation_initialize(void) 
{
    BME280_reset();
    DELAY_milliseconds(50);
    BME280_readFactoryCalibrationParams();
    BME280_config(BME280_STANDBY_HALFMS, BME280_FILTER_COEFF_OFF);
    
    // 設定為 FORCED Mode
    // BME280_ctrl_meas(BME280_OVERSAMP_X1, BME280_OVERSAMP_X1, BME280_FORCED_MODE);
    
    // 設定為 NORMAL Mode 
    BME280_ctrl_meas(BME280_OVERSAMP_X1, BME280_OVERSAMP_X1, BME280_NORMAL_MODE);
    BME280_ctrl_hum(BME280_OVERSAMP_X1);
    BME280_initializeSensor();
}
